from django.contrib import admin
from publisher.models import Publication

admin.site.register(Publication)