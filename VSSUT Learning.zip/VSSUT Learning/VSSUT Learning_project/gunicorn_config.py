command = '/usr/home/django/vssutlearning-django/env/bin/gunicorn'
pythonpath = '/usr/home/django/vssutlearning-django/vssutlearning_project'
bind = '127.0.0.1:8001'
workers = 3
