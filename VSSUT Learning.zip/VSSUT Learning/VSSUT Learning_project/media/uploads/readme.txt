This directory is where all the files will get saved to when users upload stuff.

-Bart